KAMBEN ALWAR — PORTFOLIO WEBSITE

Files:
- index.html: the complete responsive portfolio website.

PUBLISH FREE WITH GITHUB PAGES
1. Create or sign in to a GitHub account at https://github.com/
2. Create a new public repository named: kamben-alwar-portfolio
3. Upload index.html to the repository's root folder (not inside another folder).
4. Open the repository's Settings → Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait a few minutes. Your website should be published at:
   https://YOUR-GITHUB-USERNAME.github.io/kamben-alwar-portfolio/

Replace YOUR-GITHUB-USERNAME with your actual GitHub username. Paste the final published URL into the Professional Portfolio field on MyJob.

BEFORE PUBLISHING
- Check your email and phone number.
- Add genuine project screenshots/results when you have completed networking labs.
- Do not claim a lab or certification is completed until it is.
